package de.uk.java;

import java.util.Scanner;

public class Application {
	
	public static void main(String[] args) {
		
		// Der Code soll ab hier nicht angerührt werden
		// Scanner erstellen
		Scanner scanner = new Scanner(System.in);
		
		// Konsolenausgabe - Aufruf zur Eingabe
		System.out.println("ANGEBOTE");
		System.out.println("Überprüfe ob ein eingegebenes Produkt im Angebot ist:");
		
		// Eingabe lesen und als Variable speichern
		String artikel = scanner.nextLine();
		
		// Methode aufrufen. gespeicherte Eingabe wird mitgegeben
		checkDeals(artikel);
		
		// Scanner schließen
		scanner.close();
		
		// Bis hier soll der Code nicht angerührt werden
	}
	
	/**
	 * checkDeals takes a String as parameter and 
	 * checks if the String corresponds to a product and if it is on sale
	 * Prints the product status on the console
	 * @param artikel - String. User input to be checked
	 */
	static void checkDeals(String artikel) {
		switch(artikel) {
		case "Milch":
		case "Eier":
			System.out.println("Dein Produkt ist im Angebot. 10% Rabatt");
			break;
		case "Butter":
		case "Kartoffeln":
			System.out.println("Dein Produkt ist im Angebot. 20% Rabatt");
			break;
		case "Klopapier":
		case "Hefe":
			System.out.println("Dein Produkt ist zwar im Angebot, aber leider schon ausverkauft.");
			break;
		case "Schokolade":
		case "Apfelsaft":
			System.out.println("Dein Produkt ist nicht im Angebot.");
			break;
		default:
			System.err.println("Dein Produkt konnte nicht gefunden werden.");
		}
	}

}
